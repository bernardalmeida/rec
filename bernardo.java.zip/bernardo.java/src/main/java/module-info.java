module com.example.bernardo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bernardo to javafx.fxml;
    exports com.example.bernardo;
}