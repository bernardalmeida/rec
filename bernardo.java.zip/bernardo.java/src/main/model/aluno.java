package model.aluno

public class aluno {


    public string matricula
    public string media

    public string getMatricula() {
        return matricula;
    }

    public void setMatricula(string matricula) {
        this.matricula = matricula;




    }

    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        if (!super.equals(object)) return false;
        aluno aluno = (aluno) object;
        return java.util.Objects.equals(matricula, aluno.matricula) && java.util.Objects.equals(media, aluno.media);
    }

    public int hashCode() {
        return Objects.hash(super.hashCode(), matricula, media);


    }

    @java.lang.Override
    public java.lang.String toString() {
        return "aluno{" +
                "matricula=" + matricula +
                ", media=" + media +
                '}';
    }








