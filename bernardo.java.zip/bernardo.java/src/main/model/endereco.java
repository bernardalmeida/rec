package model.endereco

public class emdereco {

   public sting rua
   public string cidade
   public string uf
   public string cep
   public string pais

    public sting getRua() {
        return rua;
    }

    public void setRua(sting rua) {
        this.rua = rua;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "emdereco{" +
                "rua=" + rua +
                ", cidade=" + cidade +
                ", uf=" + uf +
                ", cep=" + cep +
                ", pais=" + pais +
                '}';
    }
}