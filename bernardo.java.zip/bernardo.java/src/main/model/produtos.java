package model.produtos

public class produtos {

    public string nome;
    public string preco;

    public sting getnome


}