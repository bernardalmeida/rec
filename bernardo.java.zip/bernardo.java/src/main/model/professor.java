package model.professor

public class professor {

    public string salario
}