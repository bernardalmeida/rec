package model.pessoa

public class pessoa {

     public string nome
     public string telefone
     public string email

     public string getNome() {
          return nome;
     }

     public void setNome(string nome) {
          this.nome = nome;
     }


}